from flask import Flask, request, jsonify
from flask_cors import CORS
import openai

app = Flask(__name__)  # ✅ 確保這行存在
CORS(app)  # 允許跨域請求

openai.api_key = "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"  # 請填入你的 API Key

# 茶飲推薦邏輯
def recommend_tea(user_responses):
    if user_responses.get("not_sleeping_well"):
        return "洛神烏梅釀 (Roselle Ume Tea)"
    return "青草茶 (Mesona Mint Tea)"  # 預設推薦

# AI 角色設定為「安爺爺」
def ask_gpt_for_response(user_message):
    response = openai.ChatCompletion.create(
        model="gpt-4o-mini",  # ✅ 使用最便宜的 GPT-4o Mini
        messages=[
            {"role": "system", "content": "你是一位溫暖、專業的草本茶顧問，名叫安爺爺，來自老濟安 Healing Herbar。你的回答要有親切長輩的感覺，並且幫助使用者推薦適合的茶飲。"},
            {"role": "user", "content": user_message}
        ]
    )
    return response["choices"][0]["message"]["content"]


@app.route("/analyze", methods=["POST"])
def analyze():
    data = request.json
    recommended_tea = recommend_tea(data)  # 內建推薦邏輯
    gpt_response = ask_gpt_for_response(f"使用者需要推薦飲品，他的症狀是：{data}. 你是安爺爺，請用你的語氣推薦一款適合的飲品。")

    return jsonify({
        "recommendation": recommended_tea,
        "gpt_reply": gpt_response
    })

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
