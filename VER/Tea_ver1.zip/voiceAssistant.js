import { menuItems } from './menuData.js';

console.log("載入菜單資料：", menuItems); // 測試是否有成功載入


// 選取按鈕區域與互動區塊
const buttonContainer = document.querySelector(".button-container");
const interactionSection = document.querySelector(".chat-options");
const sendButton = document.getElementById("send");
// 一開始隱藏「是 / 否」按鈕與下半部互動區
buttonContainer.style.display = "none";
interactionSection.style.display = "none";

// AI 歡迎語
function showWelcomeMessage() {
    const chatBox = document.getElementById("gpt-response");
    chatBox.textContent = "🌿 歡迎來到老濟安 Healing Herbar！我是安爺爺，你的 AI 草本茶顧問。為了讓我們一起喝茶的時候，是最適合於你的茶飲，待會請盡量回答我的問題囉！我會推薦適合的茶飲 🍵 給你！🌿 Welcome to Healing Herbar! I’m Grandpa An, your AI herbal tea advisor. To find the perfect tea for you, please answer my questions carefully! 🍵 I’ll recommend the best tea for you!";
    
    // 設定 10 秒後檢查使用者是否有輸入
    setTimeout(checkUserInteraction, 10000);
}

// 檢查使用者是否有輸入
function checkUserInteraction() {
    const userInput = document.getElementById("user-input").value;
    
    // 如果 10 秒內沒有輸入，自動進入問卷調查
    if (!userInput.trim()) {
        startQuestionnaire(); // 啟動問卷
    }
}
// 啟動問卷調查
function startQuestionnaire() {
    askNextQuestion(); // 顯示第一個問題
}


// 問卷問題
const questions = [
    { text: "🌿 孩子啊，最近是不是翻來翻去睡不著呢？🌙 Sleep not coming easily?", key: "not_sleeping_well" },
    { text: "🌿 啊，怎麼半夜還在精神抖擻？是不是壓力太大了呢？🌟 Feeling too energetic at night?", key: "staying_well" },
    { text: "🌿 早上起來是不是連續打噴嚏？天氣變化大，身體要顧好啊！🤧 Sneezing a lot in the morning?", key: "sneezing" },
    { text: "🌿 皮膚最近是不是癢癢的啊？有沒有哪裡特別不舒服呢？🛁 Feeling itchy and uncomfortable?", key: "itching" },
    { text: "🌿 最近是不是常常覺得胃不太開心，吃東西容易脹氣或會痛呢？🍵 Stomach feeling upset?", key: "upset_stomach" },
    { text: "🌿 生理期來了心情鬱悶嗎？或是下腹悶痛呢？喝點溫暖的茶會舒服些喔！🌸 Feeling discomfort during your cycle?", key: "menstrual_disorder" },
    { text: "🌿 唉呦，怎麼這裡酸、那裡痛？是不是最近勞累過度了？💪 Feeling muscle or joint soreness?", key: "muscle_pain" },
    { text: "🌿 眼睛會覺得酸澀、重重的嗎？是不是盯著手機或電腦太久啦？👀 Eyes feeling tired and heavy?", key: "eyes_tired" }
];


// 問題進度
let userResponses = {};
let currentQuestionIndex = 0;

// 顯示問題（並顯示按鈕）
function askNextQuestion() {
    if (currentQuestionIndex < questions.length) {
        document.getElementById("gpt-response").textContent = questions[currentQuestionIndex].text;
        buttonContainer.style.display = "flex";  // 顯示「是 / 否」按鈕
    } else {
        buttonContainer.style.display = "none";  // 問卷結束後隱藏按鈕
        sendToAI(userResponses); // 問卷結束，送資料給 AI
    }
}

// 監聽「是」按鈕
document.getElementById("yes-button").addEventListener("click", function () {
    userResponses[questions[currentQuestionIndex].key] = true;
    currentQuestionIndex++;
    buttonContainer.style.display = "none"; // 隱藏按鈕
    setTimeout(askNextQuestion, 500); // 顯示下一題
});
// 監聽「否」按鈕
document.getElementById("no-button").addEventListener("click", function () {
    userResponses[questions[currentQuestionIndex].key] = false;
    currentQuestionIndex++;
    buttonContainer.style.display = "none"; // 隱藏按鈕
    setTimeout(askNextQuestion, 500); // 顯示下一題
});

// 啟動 AI 歡迎語
document.addEventListener("DOMContentLoaded", showWelcomeMessage);
function sendToAI(userResponses) {
    fetch("https://your-api-url.onrender.com/analyze", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(userResponses)
    })
    .then(response => response.json())
    .then(data => {
        let recommendedTea = selectTeaFromMenu(data.recommendation);
        document.getElementById("gpt-response").textContent = "🍵 安爺爺推薦你：" + recommendedTea;
        unlockChatInteraction(); // 啟動下半部互動區塊
    })
    .catch(error => console.error("Error:", error));
}

// 從菜單中挑選推薦飲品
function selectTeaFromMenu(aiRecommendation) {
    for (let tea of menuItems) {
        if (aiRecommendation.includes(tea.name)) {
            return `${tea.name}，價格：${tea.price}，建議甜度：${tea.sweetness}，建議冰量：${tea.ice}`;
        }
    }
    return "🍵 安爺爺推薦你試試看青草茶 (Mesona Mint Tea)，這是最經典的選擇！";
}

// 啟動下半部互動區（填完問卷後才可使用）
function unlockChatInteraction() {
    interactionSection.style.display = "block"; // 顯示語音 & 文字輸入區塊
}

// 監聽「送出」按鈕，確保 AI 問答功能正常運作
sendButton.addEventListener("click", function () {
    const userInput = document.getElementById("user-input").value;
    if (userInput.trim()) {
        sendToGPT(userInput);
    }
});

// 連接 GPT API，處理使用者輸入
function sendToGPT(userInput) {
    fetch("https://your-api-url.onrender.com/chat", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ message: userInput })
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById("gpt-response").textContent = data.reply;
    })
    .catch(error => console.error("Error:", error));
}