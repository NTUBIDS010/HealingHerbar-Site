from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # 允許所有網域請求 API

# 茶飲推薦邏輯
def recommend_tea(user_responses):
    if user_responses.get("not_sleeping_well"):
        return "洛神烏梅釀 (Roselle Ume Tea)"
    if user_responses.get("sneezing"):
        return "地錦板藍茶 (Dijin Banlan Tea)"
    return "青草茶 (Mesona Mint Tea)"  # 預設推薦

@app.route("/analyze", methods=["POST"])
def analyze():
    data = request.json
    recommended_tea = recommend_tea(data)
    return jsonify({"recommendation": recommended_tea})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
