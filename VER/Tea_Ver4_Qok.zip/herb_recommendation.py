import pandas as pd

def load_herbs():
    # 讀取 CSV，假設第一行就是：睡不好,半暝還在嗨,早上哈啾,癢癢,胃生氣,厭世生理期,結果
    return pd.read_csv("herbs.csv", encoding="utf-8")

def get_suitable_herbs(user_responses):
    """
    user_responses 會像：
    {
      "睡不好": "焦慮",
      "半暝還在嗨": "22點以前",
      "胃生氣": ["胃脹氣","反胃"],  # 多選題
      ...
    }
    """
    herbs_df = load_herbs()
    matching_herbs = set()

    # 逐行檢查
    for index, row in herbs_df.iterrows():
        # row 的結構類似：
        # {
        #   "睡不好": "感到焦慮",
        #   "半暝還在嗨": "22點以前入睡",
        #   "早上哈啾": "長期，伴有呼吸胸悶",
        #   "癢癢": "長期過敏",
        #   "胃生氣": "胃脹氣",
        #   "厭世生理期": "重度疼痛",
        #   "結果": "[‘魚腥草 0.25g’, ...]"
        # }

        # 檢查該列是否匹配使用者回答
        for key, value in user_responses.items():
            # key: "睡不好" / "半暝還在嗨" / ...
            # value: 可能是 string 或 list (多選)

            if key not in row:  
                # CSV 裡若沒有這個欄位，就跳過
                continue

            # 如果是多選陣列，每個選項都嘗試比對
            if isinstance(value, list):
                for v in value:
                    # 只要有任一選項部分匹配該 cell 就當作命中
                    cell_value = str(row[key])  # 轉成字串比對
                    if pd.notna(cell_value) and (v in cell_value):
                        matching_herbs.add(row["結果"])
                        break  # 不用再比該 cell 的其他選項
            else:
                # 單選：直接檢查是否部分匹配
                cell_value = str(row[key])
                if pd.notna(cell_value) and (value in cell_value):
                    matching_herbs.add(row["結果"])

    if not matching_herbs:
        return ["無適合配方"]
    return list(matching_herbs)
