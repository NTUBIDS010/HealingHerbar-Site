import openai
import os
import json
import traceback
from flask import Flask, request, jsonify
from flask_cors import CORS
from dotenv import load_dotenv
from herb_recommendation import get_suitable_herbs

app = Flask(__name__)
CORS(app)

# ✅ 讀取環境變數
load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")

# ✅ 讀取菜單
try:
    with open("menuData.json", "r", encoding="utf-8") as f:
        menu_items = json.load(f)
except Exception as e:
    print("❌ 無法讀取 menuData.json:", str(e))
    menu_items = []

@app.route("/analyze", methods=["POST"])
def analyze():
    try:
        user_responses = request.json

        # ✅ 確保 `menu_items` 存在
        if not menu_items:
            return jsonify({"error": "無法讀取菜單資料"}), 500

        # ✅ 優化 `matched_herbs`
        matched_herbs = get_suitable_herbs(user_responses)
        matched_herbs = list(set(matched_herbs))[:5]  # 去重 & 限制數量
        matched_herbs_text = ", ".join([herb.split(" ")[0] for herb in matched_herbs])  # 只取名稱

        # ✅ 保留完整菜單（只顯示名稱、價格、類別、描述）
        menu_text = "\n".join([
            f"- {item['name']}（{item['category']} | {item['price']}）\n  {item.get('description', '無描述')}"
            for item in menu_items
        ])

        # ✅ 優化 Prompt
        prompt = f"""
        你是老濟安 AI 顧問「安爺爺」，請根據使用者的健康狀況推薦 1 款茶飲，你的回應只能於150字以內。
        
        使用者回應：
        {user_responses}

        相關草本：
        {matched_herbs_text}

        老濟安完整茶飲菜單：
        {menu_text}

        **請從菜單中選擇 1 款最適合的茶飲，不可創造新飲品！**
        
        回應格式：
        「依據你的身心狀況，適合有ooxx草本配方的茶飲，因為含有某某某某藥草，另外安爺爺推薦你這款【XXX】本店飲品，價格是 ABC，幫助你放鬆身心～🍵！！ 快來老濟安找安爺爺我一起喝茶，順便來體驗客製化茶飲吧！」
        """

        # ✅ 限制 `max_tokens`
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "system", "content": prompt}],
            max_tokens=160
        )

        return jsonify({"recommendation": response["choices"][0]["message"]["content"]})
    
    except Exception as e:
        print("❌ 伺服器錯誤：", traceback.format_exc())  # 印出完整錯誤
        return jsonify({"error": str(e)}), 500  # 回傳完整錯誤訊息

if __name__ == "__main__":
    app.run(debug=True)
