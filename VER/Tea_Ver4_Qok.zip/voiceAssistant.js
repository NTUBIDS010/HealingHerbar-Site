import { menuItems } from './menuData.js';

// 選取按鈕區域與互動區塊
const buttonContainer = document.querySelector(".button-container");
const interactionSection = document.querySelector(".chat-options");
const sendButton = document.getElementById("send");

// 一開始隱藏「是 / 否」按鈕與下半部互動區
buttonContainer.style.display = "none";
interactionSection.style.display = "none";

// AI 歡迎語
function showWelcomeMessage() {
    const chatBox = document.getElementById("gpt-response");
    chatBox.textContent = "🌿 歡迎來到老濟安 Healing Herbar！我是安爺爺，你的 AI 草本茶顧問。為了讓我們一起喝茶的時候，是最適合於你的茶飲，待會請盡量回答我的問題囉！我會推薦適合的茶飲 🍵 給你！🌿 Welcome to Healing Herbar! I’m Grandpa An, your AI herbal tea advisor. To find the perfect tea for you, please answer my questions carefully! 🍵 I’ll recommend the best tea for you!";

    // **✅ 讓問卷自動啟動**
    setTimeout(startQuestionnaire, 10000);  // 3 秒後開始問卷
}

// 問卷問題
const questions = [
    { text: "🌿 孩子，最近是不是睡不好呢？睡不好的原因是不是情緒上的問題？", key: "睡不好", type: "single", options: ["憂鬱最嚴重", "焦慮", "容易緊張", "無"] },
    { text: "🌿 半夜是不是難以入眠，常常滑手機到天亮，或是到半夜還在嗨？（入睡時間是？）", key: "半暝還在嗨", type: "single", options: ["22點以前", "22-24點", "24-3點", "3點以後"] },
    { text: "🌿 早上會不會打噴嚏？或是早上有無以下的症狀呢？", key: "早上哈啾", type: "single", options: ["長期有呼吸胸悶", "偶發有呼吸胸悶", "無呼吸胸悶", "無"] },
    { text: "🌿 皮膚有沒有覺得怪怪的啦？癢不癢？或是時常皮在癢呢？", key: "癢癢", type: "single", options: ["長期過敏", "短期過敏", "有就醫拿藥", "無"] },
    { text: "🌿 最近有沒有覺得胃怪怪的？（這個問題可以複選唷！）", key: "胃生氣", type: "multiple", options: ["胃脹氣", "反胃", "胃食道逆流", "無"] },
    { text: "🌿 來大姨媽的期間會不會痛痛？或是無生理期？", key: "厭世生理期", type: "single", options: ["重度疼痛", "輕度疼痛", "不會痛", "無生理期"] },
    { text: "🌿 你能接受有苦味的飲品嗎？", key: "接受苦的程度", type: "single", options: ["可以", "不行"] }
];

// 問題進度
let userResponses = {};
let currentQuestionIndex = 0;

// 顯示問題
function askNextQuestion() {
    if (currentQuestionIndex < questions.length) {
        let question = questions[currentQuestionIndex];
        document.getElementById("gpt-response").textContent = question.text;
        buttonContainer.innerHTML = ""; // 清空按鈕

        // 單選題
        if (question.type === "single") {
            question.options.forEach(option => {
                let btn = document.createElement("button");
                btn.textContent = option;
                btn.onclick = function () {
                    userResponses[question.key] = option;
                    currentQuestionIndex++;
                    askNextQuestion();
                };
                buttonContainer.appendChild(btn);
            });

        // 多選題
        } else if (question.type === "multiple") {
            if (!userResponses[question.key]) {
                userResponses[question.key] = [];
            }

            question.options.forEach(option => {
                let btn = document.createElement("button");
                btn.textContent = option;

                btn.onclick = function () {
                    let selectedOptions = userResponses[question.key];

                    if (option === "無") {
                        selectedOptions = ["無"];
                    } else {
                        if (selectedOptions.includes("無")) {
                            selectedOptions = [];
                        }
                        if (selectedOptions.includes(option)) {
                            selectedOptions = selectedOptions.filter(item => item !== option);
                        } else {
                            selectedOptions.push(option);
                        }
                    }

                    userResponses[question.key] = selectedOptions;
                    updateButtonColors();
                };

                buttonContainer.appendChild(btn);
            });

            function updateButtonColors() {
                buttonContainer.querySelectorAll("button").forEach(b => {
                    b.style.backgroundColor = userResponses[question.key].includes(b.textContent) ? "#90ee90" : "";
                });
            }
        }

        // 「下一題」按鈕
        let nextBtn = document.createElement("button");
        nextBtn.textContent = "下一題";
        nextBtn.onclick = function () {
            if (!(question.key in userResponses)) {
                userResponses[question.key] = question.type === "multiple" ? ["無"] : "無";
            }
            currentQuestionIndex++;
            askNextQuestion();
        };
        buttonContainer.appendChild(nextBtn);

        buttonContainer.style.display = "flex";

    } else {
        // 若已經沒有問題，送資料到後端
        buttonContainer.style.display = "none";
        sendToAI(userResponses);
    }
}

// **✅ 啟動問卷**
function startQuestionnaire() {
    buttonContainer.style.display = "flex"; // 確保按鈕顯示
    askNextQuestion();
}

// 監聽「是 / 否」按鈕
document.getElementById("yes-button").addEventListener("click", function () {
    userResponses[questions[currentQuestionIndex].key] = true;
    currentQuestionIndex++;
    askNextQuestion();
});

document.getElementById("no-button").addEventListener("click", function () {
    userResponses[questions[currentQuestionIndex].key] = false;
    currentQuestionIndex++;
    askNextQuestion();
});

// 送資料到 AI
function sendToAI(userResponses) {
    fetch("http://127.0.0.1:5000/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(userResponses)
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById("gpt-response").textContent = data.recommendation;
        unlockChatInteraction();
    })
    .catch(error => console.error("Error:", error));
}

// **✅ 讓問卷自動啟動**
document.addEventListener("DOMContentLoaded", showWelcomeMessage);

// 啟動下半部互動區（填完問卷後才可使用）
function unlockChatInteraction() {
    interactionSection.style.display = "block"; // 顯示語音 & 文字輸入區塊
}

// 使用者輸入 GPT
function sendToGPT(userInput) {
    fetch("http://127.0.0.1:5000/analyze", {  // 改成 analyze API
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ message: userInput })
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById("gpt-response").textContent = `安爺爺：${data.reply}`;
    })
    .catch(error => console.error("Error:", error));
}
